import json


if __name__ == "__main__":
    with open("products/product.json", "r") as f, open("products/new_prod.json", 'r') as n, open("products/322323.json", 'w') as k:
        a = json.load(f)
        b = json.load(n)
        c = a + b
        d = sorted(c, key=lambda x: x['pk'])
        json.dump(d, k, indent=2)